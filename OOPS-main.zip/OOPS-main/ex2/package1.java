class distance{
	public double m2km(double d){
		return d/1000; 
}
	public double km2m(double d){
		return d*1000;
}
	public double mi2km(double d){
		return d*1.60934;
}
	public double km2mi(double d){
		return d/1.60934;
}
}
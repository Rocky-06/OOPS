import java.util.*;
 class currency{
	public double d2i(double s){
		return s*79;
}
	public double i2d(double s){
		return s/79;
}
	public double e2i(double s){
		return s*81;
}
	public double i2e(double s){
		return s/81;
}
	public double y2i(double s){
		return (s*1.66);
}
	public double i2y(double s){
		return (s/1.66);
}
}



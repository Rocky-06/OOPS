class time{
	public double h2m(double t){
		return t*60;
}
	public double m2h(double t){
		return t/60;
}
	public double h2s(double t){
		return t*3600;
}
	public double s2h(double t){
		return t/3600;
}
}
